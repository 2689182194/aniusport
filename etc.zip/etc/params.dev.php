<?php

return [
    'adminEmail' => 'admin@example.com',
    'site_name' => '微信信息交换机',
];
