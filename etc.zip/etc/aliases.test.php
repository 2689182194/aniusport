<?php
/**
 * config array of created custom aliases .
 * User: ezsky
 * Date: 2016/11/1
 */

return [];